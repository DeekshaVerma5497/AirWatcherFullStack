package com.stackroute.airwatcher.controller;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.stackroute.airwatcher.AirwatcherApplication;
import com.stackroute.airwatcher.domain.AirWatcher;
import com.stackroute.airwatcher.repository.CityRepository;
import com.stackroute.airwatcher.service.CityService;

@RunWith(SpringRunner.class)
@WebMvcTest(CityController.class)
@ContextConfiguration(classes=AirwatcherApplication.class)
public class CityControllerTest {


	@Autowired
	private transient MockMvc mvc;
	
	@MockBean
	private transient CityService cityService;
	
	@InjectMocks
	private CityController cityController;

	public CityControllerTest() {
		// TODO Auto-generated constructor stub
	}
	
	private AirWatcher airWatcher;
	private AirWatcher airWatcher2;
	private String token;
	private transient List<AirWatcher> airWatcherList=new ArrayList<AirWatcher>();

	@Before
	public void setUpMocks()
	{
		MockitoAnnotations.initMocks(this);
		airWatcher=new AirWatcher(0, "Etawah", "Uttar Pradesh", "India", 199, 200, new Date(), "123456");
		airWatcherList.add(airWatcher);
		airWatcher2=new AirWatcher(0, "Kanpur", "Uttar Pradesh", "India", 148, 200, new Date(), "123456");
		airWatcherList.add(airWatcher2);
		token="Bearer eyJhbGciOiJIUzM4NCJ9.eyJzdWIiOiIxMjM0NTYiLCJpYXQiOjE1MzY2NDIzNjh9.hWxT0EugLV4MG7NgL7roVR7fouzp3YVHuLEkCS3Mzb9O67eLC8Ulv6Qbg2vDOUv9";
	}
	
	@Test
	public void testGetWatcher()throws Exception
	{
		when(cityService.findWatcher("1")).thenReturn(airWatcherList);
		mvc.perform(get("/api/city/").header("Authorization", token)).andExpect(status().isOk()).andDo(print());
		verify(cityService,times(1)).findWatcher(Mockito.anyString());
		verifyNoMoreInteractions(cityService);
	}
	
	/*@Test
	public void testGetWatcherById()throws Exception
	{
		when(cityService.findWatcherById(1)).thenReturn(airWatcherList.get(0));
		mvc.perform(get("/api/city/{id}",1).header("Authorization", token)).andExpect(status().isOk());
		verify(cityService,times(1)).findWatcherById(1);
		verifyNoMoreInteractions(cityService);
	}
	
	@Test
	public void testGetWatcherByCity()throws Exception
	{
		when(cityService.findWatcherByCities("Etawah")).thenReturn(airWatcherList);
		mvc.perform(get("/api/city/name/{city}","Etawah").header("Authorization", token)).andExpect(status().isOk()).andDo(print());
		verify(cityService,times(1)).findWatcherByCities(Mockito.anyString());
		verifyNoMoreInteractions(cityService);
	}*/
	
	@Test
	public void testSaveWatcher()throws Exception
	{
		when(cityService.saveWatcher(airWatcher,"123456")).thenReturn(true);
		mvc.perform(post("/api/city/").header("Authorization",token).contentType(MediaType.APPLICATION_JSON).content(jsonToString(airWatcher))).andExpect(status().isCreated());
		verify(cityService,times(1)).saveWatcher(Mockito.any(AirWatcher.class),Mockito.anyString());
		verifyNoMoreInteractions(cityService);
	}

	@Test
	public void testDeleteWatcher()throws Exception
	{
		when(cityService.deleteWatcherById("123456",0)).thenReturn(true);
		mvc.perform(delete("/api/city/{id}",0).header("Authorization", token)).andExpect(status().isOk());
		verify(cityService,times(1)).deleteWatcherById("123456",0);
		verifyNoMoreInteractions(cityService);
	}

	
	private static String jsonToString(final Object obj)throws JsonProcessingException
	{
		String result;
		try{
			final ObjectMapper mapper=new ObjectMapper();
			final String  jsonContent=mapper.writeValueAsString(obj);
			result=jsonContent;
		}
		catch(JsonProcessingException e)
		{
			result="JsonProcessingException";
		}
		return  result;
	}




	

	
}
