package com.stackroute.airwatcher.repository;

import static org.assertj.core.api.Assertions.assertThat;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import javax.transaction.Transactional;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import com.stackroute.airwatcher.AirwatcherApplication;
import com.stackroute.airwatcher.domain.AirWatcher;

@RunWith(SpringRunner.class)
@DataJpaTest
@AutoConfigureTestDatabase(replace=Replace.NONE)
@ContextConfiguration(classes=AirwatcherApplication.class)
@Transactional
public class CityRepositoryTest {

	@Autowired
	private  transient CityRepository cityRepository;
	private AirWatcher airWatcher;
	private AirWatcher airWatcher2;
	
	public void setMovieRepo(final CityRepository cityRepository) {
		this.cityRepository=cityRepository;
	}

	@Before
	public void setUp()
	{
		airWatcher=new AirWatcher(0, "Etawah", "Uttar Pradesh", "India", 148, 200, new Date(), "1");
		airWatcher2=new AirWatcher(0, "Kanpur", "Uttar Pradesh", "India", 148, 200, new Date(), "1");
	}
	
	@After 
	public void delete()
	{
		cityRepository.deleteAllInBatch();
	}
	
	@Test
	public void testGetWatcher()throws Exception
	{	
		final AirWatcher existingWatcher=cityRepository.save(airWatcher);		
		final List<AirWatcher> cityList=cityRepository.findByUserId("1");
		Assert.assertEquals(cityList.get(0).getCity(),existingWatcher.getCity());
	}
	
	@Test
	public void testGetWatcherByCity()throws Exception
	{
		cityRepository.save(airWatcher);
		cityRepository.save(airWatcher2);
		final List<AirWatcher> movieList=cityRepository.findByCity("Etawah");
		Assert.assertEquals(movieList.get(0).getCity(),"Etawah");
	}
	
	@Test
	public void testGetWatcherById()throws Exception
	{
		final AirWatcher savedWatcher=cityRepository.save(airWatcher);
		final AirWatcher newWatcher=cityRepository.findById(savedWatcher.getId()).get();	
		Assert.assertEquals(newWatcher.getCity(),"Etawah");
	}
	
	@Test
	public void testSaveWatcher()throws Exception
	{
		final AirWatcher savedWatcher=cityRepository.save(airWatcher);
		final AirWatcher newWatcher=cityRepository.findById(savedWatcher.getId()).get();
		assertThat(newWatcher.getId()).isEqualTo(savedWatcher.getId());
	}

	@Test
	public void testUpdateWatcher()throws Exception
	{
		final AirWatcher savedWatcher=cityRepository.save(airWatcher);
		final AirWatcher newWatcher=cityRepository.findById(savedWatcher.getId()).get();	
		assertThat(newWatcher.getCity()).isEqualTo("Etawah");
		newWatcher.setAqicn(150);
		cityRepository.save(newWatcher);
		final AirWatcher updatedWatcher=cityRepository.findById(newWatcher.getId()).get();
		Assert.assertEquals(150,updatedWatcher.getAqicn());
	}

	@Test
	public void testDeleteCityWatcher()throws Exception
	{
		final AirWatcher savedCityWatcher=cityRepository.save(airWatcher);
		final AirWatcher getCityWatcher=cityRepository.findById(savedCityWatcher.getId()).get();		
		assertThat(getCityWatcher.getCity()).isEqualTo("Etawah");
		cityRepository.delete(airWatcher);
		Assert.assertEquals(Optional.empty(),cityRepository.findById(savedCityWatcher.getId()));
	}


	

	
}
