package com.stackroute.airwatcher.service;

import java.util.Optional;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.stackroute.airwatcher.domain.AirWatcher;
import com.stackroute.airwatcher.exception.CityAlreadyExistException;
import com.stackroute.airwatcher.exception.CityNotFoundException;
import com.stackroute.airwatcher.repository.CityRepository;

public class CityServiceTest {
	
	@Mock
	private transient CityRepository cityRepository;
	
	@InjectMocks
	private transient CityServiceImpl cityServiceImpl;
	
	public CityServiceTest() {	}
	
	private AirWatcher airWatcher;
	private transient Optional<AirWatcher> optionalWatcher;	
	
	@Before
	public void setUpMocks()
	{
		MockitoAnnotations.initMocks(this);
		airWatcher=new AirWatcher(0, "Etawah", "Uttar Pradesh", "India", 199, 200, new Date(), "1");
		optionalWatcher=Optional.of(airWatcher);
	}
	
	@Test
	public void testMockCreation()
	{
		assertNotNull("jpaRepository creation fails:use @InjectMocks over cityServiceImpl",airWatcher);
	}
	
	@Test
	public void testGetWatcher()throws CityNotFoundException
	{
		List<AirWatcher> watcherList=new ArrayList<AirWatcher>();
		when(cityRepository.findByUserId("deeksha")).thenReturn(watcherList);
		final List<AirWatcher> watcherList1=cityServiceImpl.findWatcher("deeksha");
		assertEquals("Fetching all watcher failed",watcherList,watcherList1);
		verify(cityRepository,times(1)).findByUserId("deeksha");	
	}
	
	@Test
	public void testGetMovieById()throws CityNotFoundException
	{
		when(cityRepository.findById(airWatcher.getId())).thenReturn(optionalWatcher);
		final AirWatcher updatedWatcher=cityServiceImpl.findWatcherById(airWatcher.getId());
		assertEquals("Fetching watcher by id failed",updatedWatcher,airWatcher);
		verify(cityRepository,times(1)).findById(airWatcher.getId());	
	}

	@Test
	public void testGetAllMoviesByCity()throws CityNotFoundException
	{
		List<AirWatcher> watcherList=new ArrayList<AirWatcher>();
		when(cityRepository.findByCity("Etawah")).thenReturn(watcherList);
		final List<AirWatcher> watcherList1=cityServiceImpl.findWatcherByCities("Etawah");
		assertEquals("Fetching all movies failed",watcherList,watcherList1);
		verify(cityRepository,times(1)).findByCity("Etawah");	
	}

	
	@Test
	public void testSaveWatcherSuccess()throws CityAlreadyExistException
	{
		when(cityRepository.save(airWatcher)).thenReturn(airWatcher);
		final boolean flag=cityServiceImpl.saveWatcher(airWatcher,airWatcher.getUserId());
		assertTrue("City creation failed",flag);
		verify(cityRepository,times(1)).save(airWatcher);
		verify(cityRepository,times(1)).findByCityAndUserId(airWatcher.getCity(),airWatcher.getUserId());
	}
	
	@Test(expected=CityAlreadyExistException.class)
	public void testSaveWatcherFailure()throws CityAlreadyExistException
	{
		when(cityRepository.findByCityAndUserId(airWatcher.getCity(),airWatcher.getUserId())).thenReturn(optionalWatcher);
		when(cityRepository.save(airWatcher)).thenReturn(airWatcher);	
		final boolean flag=cityServiceImpl.saveWatcher(airWatcher,airWatcher.getUserId());
		assertFalse("Saving watcher failed",flag);
		verify(cityRepository,times(1)).findById(airWatcher.getId());
	}
	
	@Test
	public void testDeleteWatcher()throws CityNotFoundException
	{
		when(cityRepository.findByUserIdAndId("1",0)).thenReturn(optionalWatcher);
		doNothing().when(cityRepository).delete(airWatcher);
		final boolean flag=cityServiceImpl.deleteWatcherById(airWatcher.getUserId(),airWatcher.getId());
		assertTrue("Deleting Watcher failed",flag);
		verify(cityRepository,times(1)).delete(airWatcher);
		verify(cityRepository,times(1)).findByUserIdAndId(airWatcher.getUserId(), (airWatcher.getId()));	
	}
	







}
