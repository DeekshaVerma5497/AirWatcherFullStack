package com.stackroute.airwatcher.controller;

import java.util.List;

import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.stackroute.airwatcher.domain.AirWatcher;
import com.stackroute.airwatcher.exception.CityAlreadyExistException;
import com.stackroute.airwatcher.exception.CityNotFoundException;
import com.stackroute.airwatcher.service.CityService;

import io.jsonwebtoken.Jwts;

@RestController
@RequestMapping("/api/city")
@CrossOrigin
public class CityController {

	private CityService cityService;

	public CityController(final CityService cityService) {
		this.cityService=cityService;
	}
	
	public String getUserId(final HttpServletRequest request, final HttpServletResponse response) {
		final String authHeader=request.getHeader("authorization");
		final String token=authHeader.substring(7);
		final String userId=Jwts.parser().setSigningKey("secretkey").parseClaimsJws(token).getBody().getSubject();
		return userId;
	}
	
	@GetMapping("/")
	public ResponseEntity<?> getWatcher(final HttpServletRequest request, final HttpServletResponse response)
	{
		ResponseEntity<?> responseEntity;
		String userId=getUserId(request, response);
		final List<AirWatcher> watcherList=this.cityService.findWatcher(userId);
		responseEntity=new ResponseEntity<List<AirWatcher>>(watcherList,HttpStatus.OK);
		return responseEntity;
	}
	
	/*
	@GetMapping("/{id}")
	public ResponseEntity<?> getWatcherById(@PathVariable("id") final int id)
	{
		ResponseEntity<?> responseEntity;
		try {
			final AirWatcher cityWatcher =this.cityService.findWatcherById(id);
			responseEntity=new ResponseEntity<AirWatcher>(cityWatcher,HttpStatus.OK);
		} catch (CityNotFoundException e ) {
			responseEntity = new ResponseEntity<String>("{ \"message\": \"" + e.getMessage() + "\"}", HttpStatus.NOT_FOUND);
		}		
		return responseEntity;
	}

	
	@GetMapping("/name/{city}")
	public ResponseEntity<?> getWatcherByCity(@PathVariable("city") final String city)
	{
		ResponseEntity<?> responseEntity;
		final List<AirWatcher> watcherList=this.cityService.findWatcherByCities(city);
		responseEntity=new ResponseEntity<List<AirWatcher>>(watcherList,HttpStatus.OK);
		return responseEntity;
	}*/
	
	@PostMapping("/")
	public ResponseEntity<?> saveWatcher(@RequestBody final AirWatcher airWatcher, final HttpServletRequest request, final HttpServletResponse response)
	{
		ResponseEntity<?> responseEntity;
		try {
			
			String userId=getUserId(request, response);
			airWatcher.setUserId(userId);
			this.cityService.saveWatcher(airWatcher,userId);
			responseEntity = new ResponseEntity<AirWatcher>(airWatcher, HttpStatus.CREATED);
		} catch (CityAlreadyExistException e) {
			responseEntity = new ResponseEntity<String>("{ \"message\": \"" + e.getMessage() + "\"}", HttpStatus.CONFLICT);
		}		
		return responseEntity;
	}
	
	@DeleteMapping("/{id}")
	public ResponseEntity<?> deleteWatcher(@PathVariable("id")final int id, HttpServletRequest request, HttpServletResponse response)
	{
		ResponseEntity<?> responseEntity;
		try {
			String userId=getUserId(request, response);
			this.cityService.deleteWatcherById(userId,id);
			responseEntity=new ResponseEntity<String>("{ \"message\": \"" + "Watcher deleted successfully" + "\"}", HttpStatus.OK);
		} catch (CityNotFoundException e) {
			responseEntity = new ResponseEntity<String>("{ \"message\": \"" + e.getMessage() + "\"}", HttpStatus.CONFLICT);
		}		
		return responseEntity;
	}

	
	





}
