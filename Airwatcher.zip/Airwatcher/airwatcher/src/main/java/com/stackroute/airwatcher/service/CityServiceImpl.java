package com.stackroute.airwatcher.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.stackroute.airwatcher.domain.AirWatcher;
import com.stackroute.airwatcher.exception.CityAlreadyExistException;
import com.stackroute.airwatcher.exception.CityNotFoundException;
import com.stackroute.airwatcher.repository.CityRepository;

@Service
public class CityServiceImpl implements CityService {

	private final transient CityRepository cityRepository;

	public CityServiceImpl(final CityRepository cityRepository) {
		this.cityRepository = cityRepository;
	}

	/**
	 * Will display all user's airwatch
	 */

	@Override
	public List<AirWatcher> findWatcher(String userId) {
		return cityRepository.findByUserId(userId);
	}

	/**
	 * Will display all airwatch based on cities
	 */

	@Override
	public List<AirWatcher> findWatcherByCities(String city) {
		return cityRepository.findByCity(city);
	}

	/**
	 * Will find city by id
	 */

	@Override
	public AirWatcher findWatcherById(int id) throws CityNotFoundException {
		Optional<AirWatcher> optionalCity = cityRepository.findById(id);

		if (optionalCity.isPresent())
			return optionalCity.get();

		else {
			throw new CityNotFoundException("City could not be found");
		}

	}

	/**
	 * To save new city
	 */

	@Override
	public boolean saveWatcher(AirWatcher airWatcher,String userId) throws CityAlreadyExistException {
		Optional<AirWatcher> optionalCity = cityRepository.findByCityAndUserId(airWatcher.getCity(),airWatcher.getUserId());

		if (optionalCity.isPresent())
			throw new CityAlreadyExistException("Watcher already exist");

		else {
			cityRepository.save(airWatcher);
			return true;
		}

	}
	
	/**
	 * To find particular watcher and delete it
	 */

	@Override
	public boolean deleteWatcherById(final String userId,int id) throws CityNotFoundException {
		AirWatcher receivedCity=cityRepository.findByUserIdAndId(userId, id).orElse(null);
		if(receivedCity==null)
		{
			throw new CityNotFoundException("Watcher not found so can't delete");
		}
		cityRepository.delete(receivedCity);
		return true;

	}

}
