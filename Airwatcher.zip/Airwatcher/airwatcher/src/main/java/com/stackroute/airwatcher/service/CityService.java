package com.stackroute.airwatcher.service;

import java.util.List;

import com.stackroute.airwatcher.domain.AirWatcher;
import com.stackroute.airwatcher.exception.CityAlreadyExistException;
import com.stackroute.airwatcher.exception.CityNotFoundException;

public interface CityService {

	public List<AirWatcher> findWatcher(final String userId);
	
	public List<AirWatcher> findWatcherByCities(final String city);
	
	public AirWatcher findWatcherById(final int id) throws CityNotFoundException;
	
	public boolean saveWatcher(final AirWatcher airWatcher,final String userId) throws CityAlreadyExistException;
	
	public boolean deleteWatcherById(final String userId,final int id) throws CityNotFoundException;

}
