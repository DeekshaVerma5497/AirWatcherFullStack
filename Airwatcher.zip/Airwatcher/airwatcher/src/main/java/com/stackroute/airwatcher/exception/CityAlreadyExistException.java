package com.stackroute.airwatcher.exception;

@SuppressWarnings("serial")
public class CityAlreadyExistException extends Exception{

	public CityAlreadyExistException() {
		// TODO Auto-generated constructor stub
	}
	
	private String message;

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public CityAlreadyExistException(String message) {
		super();
		this.message = message;
	}

	/**
	 * This message will be returned if city already exists 
	 */
	
	@Override
	public String toString() {
		return "CityAlreadyExistException [message=" + message + "]";
	}

	

}
