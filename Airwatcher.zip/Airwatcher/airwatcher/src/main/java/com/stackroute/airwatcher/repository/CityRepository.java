package com.stackroute.airwatcher.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.stackroute.airwatcher.domain.AirWatcher;

@Repository
public interface CityRepository extends JpaRepository<AirWatcher, Integer>{
	
	Optional<AirWatcher> findByUserIdAndId(String userId,int id);
	List<AirWatcher> findByUserId(String userId);
	List<AirWatcher> findByCity(String city);
	Optional<AirWatcher> findByCityAndUserId(String city,String userId);

}
