package com.stackroute.airwatcher.exception;

@SuppressWarnings("serial")
public class CityNotFoundException extends Exception {

	private String message;
	
	public CityNotFoundException() {
		// TODO Auto-generated constructor stub
	}

	public CityNotFoundException(String message) {
		super();
		this.message = message;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	/**
	 * This message will be returned if city not found
	 */
	
	@Override
	public String toString() {
		return "CityNotFoundException [message=" + message + "]";
	}
	
	

}
