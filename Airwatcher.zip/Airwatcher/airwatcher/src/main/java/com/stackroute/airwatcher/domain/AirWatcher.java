package com.stackroute.airwatcher.domain;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.CreationTimestamp;

@Entity
@Table(name="airwatcher")
public class AirWatcher {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "id")
	private int id;
	
	@Column(name = "country")
	private String country;
	
	@Column(name = "state")
	private String state;
	
	@Column(name = "city")
	private String city;

	@Column(name = "aiqus")
	private int aqius;
	
	@Column(name = "aqicn")
	private int aqicn;
	
	@CreationTimestamp
	private Date recorded;

	@Column(name = "user_id")
	private String userId;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public int getAqius() {
		return aqius;
	}

	public void setAqius(int aqius) {
		this.aqius = aqius;
	}

	public int getAqicn() {
		return aqicn;
	}

	public void setAqicn(int aqicn) {
		this.aqicn = aqicn;
	}

	public Date getRecorded() {
		return recorded;
	}

	public void setRecorded(Date recorded) {
		this.recorded = recorded;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}	
	
	public AirWatcher() {	}

	public AirWatcher(int id, String city, String state, String country, int airus, int aircn, Date recorded,
			String userId) {
		super();
		this.id = id;
		this.country = country;
		this.state = state;
		this.city = city;
		this.aqius = airus;
		this.aqicn = aircn;
		this.recorded = recorded;
		this.userId = userId;
	}

	public AirWatcher(String country, String state, String city, int airus, int aircn, Date recorded,
			String userId) {
		super();
		this.country = country;
		this.state = state;
		this.city = city;
		this.aqius = airus;
		this.aqicn = aircn;
		this.recorded = recorded;
		this.userId = userId;
	}
	
	
	
	
	
}
