cd airwatcher
source ./env-variable.sh
cd ..
cd accountmanager
source ./env-variable.sh
cd ..
