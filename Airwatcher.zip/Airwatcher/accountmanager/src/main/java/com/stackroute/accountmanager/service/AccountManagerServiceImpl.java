package com.stackroute.accountmanager.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.stackroute.accountmanager.domain.AccountManager;
import com.stackroute.accountmanager.exception.UserAlreadyExistException;
import com.stackroute.accountmanager.exception.UserNotFoundException;
import com.stackroute.accountmanager.repository.AccountManagerRepository;

@Service
public class AccountManagerServiceImpl implements AccountManagerService{
	private final transient AccountManagerRepository accountManagerRepository;

	@Autowired
	public AccountManagerServiceImpl(AccountManagerRepository accountManagerRepository) {
		super();
		this.accountManagerRepository=accountManagerRepository;
		
	}

	@Override
	public boolean saveUser(AccountManager accountManager) throws UserAlreadyExistException {
		// TODO Auto-generated method stub
		Optional<AccountManager> optionalUser=accountManagerRepository.findById(accountManager.getUserId());
		if(optionalUser.isPresent())
		{
			throw new UserAlreadyExistException("User details cannot be saved . User already exist");
		}
		accountManagerRepository.save(accountManager);
			return true;

	}

	@Override
	public AccountManager findByUserIdAndPassword(String userId, String password) throws UserNotFoundException {
		// TODO Auto-generated method stub
		
		AccountManager accountManager=accountManagerRepository.findByUserIdAndPassword(userId, password);
		
		if(accountManager==null)
		{
			throw new UserNotFoundException("User details mismatch");
		}
		return accountManager;
	}

}
