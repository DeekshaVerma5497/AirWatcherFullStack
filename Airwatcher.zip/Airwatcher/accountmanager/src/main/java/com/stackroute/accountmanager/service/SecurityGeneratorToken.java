package com.stackroute.accountmanager.service;

import java.util.Map;

import com.stackroute.accountmanager.domain.AccountManager;

public interface SecurityGeneratorToken {

	Map<String,String> generateTokens(AccountManager accountManager);
}
