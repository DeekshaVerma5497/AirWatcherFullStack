package com.stackroute.accountmanager.service;

import com.stackroute.accountmanager.domain.AccountManager;
import com.stackroute.accountmanager.exception.UserAlreadyExistException;
import com.stackroute.accountmanager.exception.UserNotFoundException;

public interface AccountManagerService {

	public boolean saveUser(AccountManager accountManager) throws UserAlreadyExistException;
	public AccountManager findByUserIdAndPassword(String userId, String password) throws UserNotFoundException;

}
