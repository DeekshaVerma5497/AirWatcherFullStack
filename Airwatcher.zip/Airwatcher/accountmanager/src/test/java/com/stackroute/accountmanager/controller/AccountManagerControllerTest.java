package com.stackroute.accountmanager.controller;


import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.Date;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.stackroute.accountmanager.AccountmanagerApplication;
import com.stackroute.accountmanager.domain.AccountManager;
import com.stackroute.accountmanager.service.SecurityGeneratorToken;
import com.stackroute.accountmanager.service.AccountManagerServiceImpl;


@RunWith(SpringRunner.class)
@WebMvcTest(AccountManagerController.class)
@ContextConfiguration(classes=AccountmanagerApplication.class)

public class AccountManagerControllerTest {
	 @Autowired
     private MockMvc mockMvc;
     
     @MockBean
     private AccountManagerServiceImpl accountManagerServiceImpl;
     
     @MockBean
     private SecurityGeneratorToken tokenGenerator;
     
     private AccountManager accountManager;
     
     @InjectMocks
     AccountManagerController accountManagerController;
     
     @Before
     public void setUp() throws Exception{
           MockitoAnnotations.initMocks(this);
           
           accountManager=new AccountManager("deeksha", "Deeksha", "Verma", "123456", new Date());
           
     }
     
     @Test
     public void testRegisterUser() throws Exception{
           when(accountManagerServiceImpl.saveUser(accountManager)).thenReturn(true);
           mockMvc.perform(post("/manager/register").contentType(MediaType.APPLICATION_JSON)
     .accept(MediaType.APPLICATION_JSON).content(jsonToString(accountManager))).andExpect(status().isCreated())
           .andDo(print());
           verify(accountManagerServiceImpl,times(1)).saveUser(Mockito.any(AccountManager.class));
           verifyNoMoreInteractions(accountManagerServiceImpl);
           
           
     }
     
     @Test
     public void testLoginUser() throws Exception{
           String userId=accountManager.getUserId();
           String password=accountManager.getPassword();
           when(accountManagerServiceImpl.saveUser(accountManager)).thenReturn(true);
           when(accountManagerServiceImpl.findByUserIdAndPassword(userId, password)).thenReturn(accountManager);
           mockMvc.perform(post("/manager/login").contentType(MediaType.APPLICATION_JSON)
                       .content(jsonToString(accountManager))).andExpect(status().isOk());
           verify(accountManagerServiceImpl).findByUserIdAndPassword(accountManager.getUserId(), accountManager.getPassword());
           verifyNoMoreInteractions(accountManagerServiceImpl);
                       
     }
     
     private static String jsonToString(final Object obj) throws JsonProcessingException{
           String result;
           try{
                 final ObjectMapper mapper=new ObjectMapper();
                 final String jsonContent=mapper.writeValueAsString(obj);
                 result=jsonContent;
           }
           catch(JsonProcessingException e){
                 result="json processing error";
           }
           return result;
     }

}
