package com.stackroute.accountmanager.repository;

import static org.assertj.core.api.Assertions.assertThat;
import java.util.Date;
import java.util.Optional;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.junit4.SpringRunner;
import com.stackroute.accountmanager.domain.AccountManager;

@RunWith(SpringRunner.class)
@DataJpaTest
@AutoConfigureTestDatabase(replace=Replace.NONE)
public class AccountManagerRepositoryTest {

	public AccountManagerRepositoryTest() {	}
	
	@Autowired
	private AccountManagerRepository accountManagerRepository;
	
	private AccountManager accountManager;
	
	@Before
	public void setUp()
	{
		accountManager=new AccountManager("deeksha", "Deeksha", "Verma", "123456", new Date());
	}
	
	@Test
	public void testRegisterUserSuccess()
	{
		accountManagerRepository.save(accountManager);
		Optional<AccountManager> accountManagerOptional=accountManagerRepository.findById(accountManager.getUserId());
		assertThat(accountManagerOptional.equals(accountManager));
	}
	

	
	

	
}
