package com.stackroute.accountmanager.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Date;
import java.util.Optional;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.stackroute.accountmanager.domain.AccountManager;
import com.stackroute.accountmanager.exception.UserAlreadyExistException;
import com.stackroute.accountmanager.exception.UserNotFoundException;
import com.stackroute.accountmanager.repository.AccountManagerRepository;
public class AccountManagerServiceTest {

	public AccountManagerServiceTest() {
		// TODO Auto-generated constructor stub
	}

	@Mock
	private AccountManagerRepository userRepository;

	@InjectMocks
	private AccountManagerServiceImpl userServiceImpl;

	public AccountManager accountManager;

	Optional<AccountManager> options;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		accountManager = new AccountManager("deeksha", "Deeksha", "Verma", "123456", new Date());
		options = Optional.of(accountManager);
	}

	@Test
	public void testSaveMovieSuccess() throws UserAlreadyExistException {
		when(userRepository.save(accountManager)).thenReturn(accountManager);
		final boolean flag = userServiceImpl.saveUser(accountManager);
		assertEquals("Cannot Register User ", true, flag);
		verify(userRepository, times(1)).save(accountManager);
		verify(userRepository, times(1)).findById(accountManager.getUserId());

	}

	@Test(expected = UserAlreadyExistException.class)
	public void testSaveMovieFailure() throws UserAlreadyExistException {
		when(userRepository.findById(accountManager.getUserId())).thenReturn(options);
		when(userRepository.save(accountManager)).thenReturn(accountManager);
		final boolean flag = userServiceImpl.saveUser(accountManager);
		assertFalse("Cannot Register User ", flag);
		verify(userRepository, times(1)).save(accountManager);
		verify(userRepository, times(1)).findById(accountManager.getUserId());

	}

	@Test
	public void testValidateSuccess() throws UserAlreadyExistException, UserNotFoundException {
		when(userRepository.findByUserIdAndPassword(accountManager.getUserId(), accountManager.getPassword())).thenReturn(accountManager);
		AccountManager userResult = userServiceImpl.findByUserIdAndPassword(accountManager.getUserId(), accountManager.getPassword());
		assertNotNull(userResult);
		assertEquals("deeksha", userResult.getUserId());
		verify(userRepository, times(1)).findByUserIdAndPassword(accountManager.getUserId(), accountManager.getPassword());
	}

	@Test(expected=UserNotFoundException.class)
	public void testValidateFailure() throws  UserNotFoundException
	{
		when(userRepository.findByUserIdAndPassword(accountManager.getUserId(), accountManager.getPassword())).thenReturn(null);
		userServiceImpl.findByUserIdAndPassword(accountManager.getUserId(), accountManager.getPassword());
		
	}

}
