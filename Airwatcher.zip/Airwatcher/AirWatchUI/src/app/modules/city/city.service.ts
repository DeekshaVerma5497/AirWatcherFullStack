import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { Observable } from 'rxjs'
import { retry } from 'rxjs/operators'
import { City } from './city';

@Injectable({
  providedIn: 'root'
})
export class CityService {

  countryPoint: string;
  statePoint: string;
  cityPoint: string;
  cityDataPoint: string;
  imgPrefix: string;
  apikey: string;
  watchlistEndpoint: string;
  springEndPoint: string;
  search: string;

  countryflag: string;

  constructor(private http: HttpClient) {
    this.apikey = 'key=bfRkWSDGFjyLYpY9p';
    this.countryPoint = "https://api.airvisual.com/v2/countries";
    this.statePoint = "https://api.airvisual.com/v2/states?country";
    this.cityPoint = "https://api.airvisual.com/v2/cities?state";
    this.cityDataPoint = "https://api.airvisual.com/v2/city?city"
    this.springEndPoint = "http://localhost:8091/api/city/";
  }

  getCountries(): Observable<Array<string>> {
    const countryUrl = `${this.countryPoint}?${this.apikey}`;
    return this.http.get(countryUrl).pipe(retry(3), map(this.pickResults));
  }
  getStates(country: string): Observable<Array<string>> {
    const stateUrl = `${this.statePoint}=${country}&${this.apikey}`
    return this.http.get(stateUrl).pipe(retry(3), map(this.pickResults));
  }
  getCity(country: string, state: string): Observable<Array<any>> {
    const cityUrl = `${this.cityPoint}=${state}&country=${country}&${this.apikey}`;
    return this.http.get(cityUrl).pipe(retry(3), map(this.pickResults));
  }
  geCityData(country: string, state: string, city: string): Observable<any> {
    const cityDataUrl = `${this.cityDataPoint}=${city}&state=${state}&country=${country}&${this.apikey}`
    return this.http.get(cityDataUrl).pipe(retry(3), map(this.pickResults));
  }
  pickResults(response) {
    return response['data'];
  }
  getaqius(country: string, state: string, city: string): Observable<any> {
    const cityDataUrl = `${this.cityDataPoint}=${city}&state=${state}&country=${country}&${this.apikey}`
    return this.http.get(cityDataUrl).pipe(retry(3), map(this.pickMoreResults));
  }

  getaqicn(country: string, state: string, city: string): Observable<any> {
    const cityDataUrl = `${this.cityDataPoint}=${city}&state=${state}&country=${country}&${this.apikey}`
    return this.http.get(cityDataUrl).pipe(retry(3), map(this.pickMoreResults));
  }

  pickMoreResults(response) {
    return response['data']['current']['pollution'];
  }

  saveCityToWatchlist(saveCity) {
    const headers = new HttpHeaders();
    return this.http.post(this.springEndPoint, saveCity, { headers: { 'Authorization': "Bearer " + localStorage.getItem("jwt_token") } });
  }


  getCityInWatchlist(): Observable<any> {
    const headers = new HttpHeaders();
    return this.http.get(this.springEndPoint, { headers: { 'Authorization': "Bearer " + localStorage.getItem("jwt_token") } });
  }
  deleteCityFromWatchlist(city) {
    console.log(city)
    const url = `${this.springEndPoint}${city}`;
    return this.http.delete(url, { headers: { 'Authorization': "Bearer " + localStorage.getItem("jwt_token") } });
  }
  deleteFromWatchlist(city) {
    const url = `${this.springEndPoint}${city.id}`;
    return this.http.delete(url, { responseType: "text" });
  }
}
