export class City {
    id:number;
    city:string;
    state:string;
    country:string;
    user_id:string;
    aqius:number;
    aqicn:number;
       
}
