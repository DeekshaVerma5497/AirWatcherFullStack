import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CountryComponent } from './components/country/country.component';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { CityService } from './city.service';
import {MatSnackBarModule} from '@angular/material/snack-bar';
import {MatInputModule} from '@angular/material/input';
import { MatCardModule } from '@angular/material/card';
import { CityComponent } from './components/city/city.component';
import {MatGridListModule} from '@angular/material/grid-list';
import { StateComponent } from './components/state/state.component';
import { CityRoutingModule } from './city-router.module';
import { WatchlistComponent } from './components/watchlist/watchlist.component';
import {MatToolbarModule} from '@angular/material/toolbar';
import { AuthGuardService } from '../../authGuard.service';

@NgModule({
  declarations: [
    CountryComponent,
    CityComponent,
    StateComponent,
    WatchlistComponent
    ],
  entryComponents:[],
  imports: [
    CommonModule,
    HttpClientModule,
    FormsModule,
    MatCardModule,
    MatToolbarModule,
    MatSnackBarModule,
    MatInputModule,
    MatGridListModule,
    CityRoutingModule,
    MatSnackBarModule
  ],
  exports: [
    CountryComponent,
    CityComponent,
    StateComponent,
  ],
  providers:[CityService,
    AuthGuardService
  ]
})
export class CityModule { }
