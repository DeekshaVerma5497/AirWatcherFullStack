import { Component, OnInit } from '@angular/core';
import { CityService } from '../../city.service';
import { ActivatedRoute, Route, Router } from '@angular/router';

@Component({
  selector: 'app-country',
  templateUrl: './country.component.html',
  styleUrls: ['./country.component.css']
})
export class CountryComponent implements OnInit {

  city: Array<string>;
  movieType: string;
  country: Array<string>;
  states: Array<string>;

  constructor(private cityService: CityService, private route: ActivatedRoute, private routes: Router) {
    this.country = [];
    this.states = [];
  }

  ngOnInit() {
    this.cityService.getCountries().subscribe(
      (country) => {
        this.country.push(...country);
        console.log(JSON.stringify(country));
        var count
      });
  }

  onstay(con) {
    console.log(con);
    this.routes.navigate(['/airwatch/countries/', con])
  }
}
