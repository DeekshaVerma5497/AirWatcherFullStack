import { Component, OnInit } from '@angular/core';
import { CityService } from '../../city.service';
import { City } from '../../city';
import { MatSnackBar } from '@angular/material';
import { ParamMap, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-watchlist',
  templateUrl: './watchlist.component.html',
  styleUrls: ['./watchlist.component.css']
})
export class WatchlistComponent implements OnInit {

  cities: Array<City>;
  cid: string;
  sid: string;
  deleteCity
  constructor(private cityService: CityService, private router: ActivatedRoute, private matSnackBar: MatSnackBar, ) {
    this.cities = [];

  }

  ngOnInit() {

    this.cityService.getCityInWatchlist().subscribe((cities) => {
      console.log(cities)
      this.cities.push(...cities);
      console.log(cities)
      this.cities.forEach((ct) => {

        this.cityService.geCityData(ct.country, ct.state, ct.city).
          subscribe((data) => {
            ct.aqius = data.current.pollution.aqius;
            ct.aqicn = data.current.pollution.aqicn;
          })

      })
      console.log(this.cities);
    });
  }

  deleteFromWatchList(cityId) {
    console.log(cityId);
    let message = "City Deleted";
    this.cityService.deleteCityFromWatchlist(cityId).subscribe((result) => {
      this.matSnackBar.open(message, '', {
        duration: 2000
      });
    });
    const index = this.cities.indexOf(cityId);
    this.cities.splice(index, 1);
  }
}


