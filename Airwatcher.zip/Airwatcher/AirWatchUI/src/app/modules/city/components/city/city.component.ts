import { Component, OnInit, Input, Output } from '@angular/core';
import { CityService } from '../../city.service';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
import { City } from '../../city';
import { EventEmitter } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
@Component({
  selector: 'app-city',
  templateUrl: './city.component.html',
  styleUrls: ['./city.component.css']
})
export class CityComponent implements OnInit {

  city: Array<City>;
  citydata: Array<any>;
  sid: string;
  cid: string;
  citye: string;
  aqius: number;
  aqicn: number;
  saveCity
  isSpecial: boolean
  constructor(private cityService: CityService, private router: ActivatedRoute,
    private matSnackBar: MatSnackBar, private routes: Router) {
    this.city = [];
    this.citydata = [];
  }

  ngOnInit() {

    this.router.paramMap.subscribe(
      (res: ParamMap) => {
        this.cid = res.get('id');
        this.sid = res.get('id2');
        console.log(this.sid)
        this.cityService.getCity(this.cid, this.sid).subscribe((res) => {
          this.city = res;
          this.city.forEach((ct) => {

            this.cityService.geCityData(this.cid, this.sid, ct.city).
              subscribe((data) => {

                ct.city = data.city;
                ct.state = data.state;
                ct.country = data.country;
                ct.aqius = data.current.pollution.aqius;
                this.aqius = ct.aqius;
                ct.aqicn = data.current.pollution.aqicn;
                this.aqicn = ct.aqicn;
              })
          })
          console.log(this.city);
        });
      })
  }

  addCityToWatchList(citye) {
    this.saveCity = {
      "city": citye,
      "state": this.sid,
      "country": this.cid,
      "aqius": this.aqius,
      "aqicn": this.aqicn,
    }

    let message = `${this.saveCity.city} added to watchlist`;
    this.cityService.saveCityToWatchlist(this.saveCity).subscribe((result) => {
       const message1 = JSON.stringify(result);
      this.matSnackBar.open(message1+"added", '', {
        duration: 2000
      });
    },
    error=>{
        const message = JSON.stringify(error.error.message);
        this.matSnackBar.open(message, '', {
        duration: 2000
      });
    })

  }

}
