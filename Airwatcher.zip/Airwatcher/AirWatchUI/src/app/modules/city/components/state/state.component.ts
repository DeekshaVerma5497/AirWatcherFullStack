import { Component, OnInit } from '@angular/core';
import { City } from '../../city';
import { CityService } from '../../city.service';
import { ActivatedRoute, ParamMap, Router } from '@angular/router';

@Component({
  selector: 'app-state',
  templateUrl: './state.component.html',
  styleUrls: ['./state.component.css']
})
export class StateComponent implements OnInit {

  sid: string;
  states: Array<string>;
  constructor(private cityService: CityService, private router: ActivatedRoute, private routes: Router) { }

  ngOnInit() {
    this.router.paramMap.subscribe(
      (res: ParamMap) => {
        this.sid = res.get('id')
        console.log(this.sid)
        this.cityService.getStates(this.sid).subscribe((res) => {
          this.states = res;
        });
      }
    )
  }

  onstay(state) {
    console.log(state);
    this.routes.navigate(['/airwatch/countries/', this.sid, state])
  }

}
