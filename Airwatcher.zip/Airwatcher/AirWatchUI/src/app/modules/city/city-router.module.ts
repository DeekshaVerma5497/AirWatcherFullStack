import { CountryComponent } from "./components/country/country.component";
import { StateComponent } from './components/state/state.component';
import { NgModel } from '@angular/forms';
import { NgModule, Component } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CityComponent } from './components/city/city.component';
import { WatchlistComponent } from './components/watchlist/watchlist.component';
import { AuthGuardService } from '../../authGuard.service';

const airwatchRoutes:Routes=[
    {

    path:'airwatch',
    children:[
        {
            path:'',
            redirectTo:'/airwatch/countries',
            pathMatch:'full',
            canActivate: [AuthGuardService]

        },
        {
            path:'countries',
            component:CountryComponent,
             canActivate: [AuthGuardService]
        },
        {
            path:'countries/:id',
            component:StateComponent,
            canActivate: [AuthGuardService]
        },
        {
            path:'countries/:id/:id2',
            component:CityComponent,
            canActivate: [AuthGuardService]
        },
        {
            path:'watchlist',
            component:WatchlistComponent,
            canActivate: [AuthGuardService]
        }
    ]

}
];
@NgModule({
    imports: [RouterModule.forChild(airwatchRoutes)],
    exports:[RouterModule]
})
export class CityRoutingModule {}