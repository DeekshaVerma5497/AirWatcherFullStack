import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CityModule } from './modules/city/city.module';
import { MatToolbarModule} from '@angular/material/toolbar';
import {MatDialogModule} from '@angular/material/dialog';
import { MatButtonModule, MatButton } from '@angular/material/button'
import { MatGridListModule } from '@angular/material/grid-list';
import { AuthenticationModule } from './modules/authentication/authentication.module';
import { AuthGuardService } from './authGuard.service';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

@NgModule({
  declarations: [
    AppComponent
    ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    CityModule,
    MatToolbarModule,
    MatDialogModule,
    MatButtonModule,
    MatGridListModule,
    AuthenticationModule,
    BrowserAnimationsModule
  ],
  providers: [AuthGuardService],
  bootstrap: [AppComponent]
})
export class AppModule { }
