import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { MatToolbarModule, MatToolbar } from '@angular/material/toolbar';
import { AuthenticationService } from './modules/authentication/authentication.service';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Air Watcher';

  constructor(private auth:AuthenticationService,private routes:Router){}

 Logout(){
   this.auth.deleteToken();
   this.routes.navigate(['/login'])
 }

}
