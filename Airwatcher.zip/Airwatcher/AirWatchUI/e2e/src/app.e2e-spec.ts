import { AppPage } from './app.po';
import { browser, by, element, protractor } from 'protractor';
import { async } from 'q';

describe('Air Watcher App', () => {
  let page: AppPage;

  beforeEach(() => {
    page = new AppPage();
  });

  it('should display title', () => {
    page.navigateTo();
    expect(browser.getTitle()).toEqual('AirWatchUI');
  });

  it('should be redirected to /login route on opening the application', () => {
    browser.driver.sleep(2000);    
    expect(browser.getCurrentUrl()).toContain('/login');
  });

  it('should be redirected to /register route', () => {
    browser.driver.sleep(2000);    
    browser.element(by.css('.register-button')).click();
    expect(browser.getCurrentUrl()).toContain('/register');
  });

  it('should be able to register user', () => {
    browser.driver.sleep(2000);    
    browser.element(by.id('firstName')).sendKeys('Super User');
    browser.element(by.id('lastName')).sendKeys('Super lastUser');
    browser.element(by.id('userId')).sendKeys('Super User12');
    browser.element(by.id('password')).sendKeys('Super Userpass');
    browser.element(by.css('.register-user')).click();
    expect(browser.getCurrentUrl()).toContain('/login');
  });
  

  it('should be able to login user and navigate to countries', () => {
    browser.driver.sleep(2000);    
    browser.element(by.id('userId')).sendKeys('Super User12');
    browser.element(by.id('password')).sendKeys('Super Userpass');
    browser.element(by.css('.login-user')).click();
    expect(browser.getCurrentUrl()).toContain('/airwatch/countries');
  });
  

  it('should be able to navigate to states on click on country',()=>{
    browser.driver.manage().window().maximize();
    browser.driver.sleep(4000);
    const searchItems=element.all(by.css('.card-header'));
    expect(searchItems.count()).toBe(104);
    searchItems.get(0).click();
    //browser.element(by.css('.card-header')).click();
    expect(browser.getCurrentUrl()).toContain('/airwatch/countries/Afghanistan');
  });

  it('should be able to navigate to cities with arirwatch on click on state',()=>{
    browser.driver.manage().window().maximize();
    browser.driver.sleep(4000);
    const searchItems=element.all(by.css('.card-header'));
    expect(searchItems.count()).toBe(1);
    searchItems.get(0).click();
    //browser.element(by.css('.card-header')).click();
    expect(browser.getCurrentUrl()).toContain('/airwatch/countries/Afghanistan/Kabul');
  });

  it('should be able to add movie to watchlist', async() => {
    browser.driver.manage().window().maximize();
    browser.driver.sleep(4000);
    const searchItems = element.all(by.css('.movie-thumbnail'));
    expect(searchItems.count()).toBe(1);
    searchItems.get(0).click();
    browser.element(by.css('.btn')).click();
    browser.driver.sleep(5000);
  });
 
});
