cd airwatcher
source ./env-variable.sh
mvn clean package
cd ..
cd accountmanager
source ./env-variable.sh
mvn clean package
cd ..
